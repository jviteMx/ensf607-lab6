# ensf607-lab6
I did this assigment by my self, no teams involved so its only for my marks.

1)simple client excercise

2)date time server

3)tic tac toe threadpool

4)gui tick tac toe.
