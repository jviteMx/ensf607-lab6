

public interface Constants {// all characters here are final and they are X(for player 1),O(for player 2)
	static final char SPACE_CHAR = ' ';
	static final char LETTER_O = 'O';//player 1
	static final char LETTER_X = 'X';//player 2
}
